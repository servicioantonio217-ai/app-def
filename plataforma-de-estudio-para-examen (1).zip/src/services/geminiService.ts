
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { ExamQuestion, Flashcard, QuizQuestion } from '../../types';

if (!process.env.API_KEY) {
    throw new Error("La clave de API de Gemini no está configurada. Asegúrate de que la variable de entorno API_KEY esté configurada.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
const model = "gemini-2.5-flash";

export const generateModuleContent = async (moduleTitle: string): Promise<string> => {
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: model,
            contents: `Eres un profesor experto. Genera un resumen educativo completo pero conciso sobre el tema: "${moduleTitle}". Estructura el contenido con encabezados y listas de viñetas para que sea fácil de leer y estudiar. El resumen debe cubrir los conceptos clave, las definiciones importantes y los puntos principales.`,
        });

        return response.text.replace(/\*/g, '•');
    } catch (error) {
        console.error("Error al generar el contenido del módulo:", error);
        throw new Error("No se pudo generar el contenido del módulo. Inténtalo de nuevo.");
    }
};


export const generateExam = async (): Promise<ExamQuestion[]> => {
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: model,
            contents: `Crea un simulacro de examen de 10 preguntas de opción múltiple que cubran un rango general de temas de conocimiento (historia, ciencia, geografía). Cada pregunta debe tener 4 opciones y una respuesta correcta claramente identificada. Asegúrate de que las opciones sean plausibles y las preguntas sean desafiantes pero justas.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            pregunta: {
                                type: Type.STRING,
                                description: "La pregunta del examen.",
                            },
                            opciones: {
                                type: Type.ARRAY,
                                items: { type: Type.STRING },
                                description: "Un arreglo de 4 posibles respuestas.",
                            },
                            respuestaCorrecta: {
                                type: Type.STRING,
                                description: "La respuesta correcta exacta de entre las opciones.",
                            },
                        },
                        required: ["pregunta", "opciones", "respuestaCorrecta"],
                    },
                },
            },
        });
        
        const jsonText = response.text.trim();
        const quiz = JSON.parse(jsonText);
        return quiz;
    } catch (error) {
        console.error("Error al generar el examen:", error);
        throw new Error("No se pudo generar el examen. Inténtalo de nuevo.");
    }
};

export const generateFlashcards = async (topic: string): Promise<Flashcard[]> => {
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: model,
            contents: `Genera 5 flashcards sobre el tema "${topic}". Cada flashcard debe tener una pregunta y una respuesta corta y concisa.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            pregunta: {
                                type: Type.STRING,
                                description: "La pregunta o término en el anverso de la tarjeta.",
                            },
                            respuesta: {
                                type: Type.STRING,
                                description: "La respuesta o definición en el reverso de la tarjeta.",
                            },
                        },
                        required: ["pregunta", "respuesta"],
                    },
                },
            },
        });
        
        const jsonText = response.text.trim();
        const flashcards = JSON.parse(jsonText);
        return flashcards;
    } catch (error) {
        console.error("Error al generar las flashcards:", error);
        throw new Error("No se pudieron generar las flashcards. Inténtalo de nuevo.");
    }
};

export const generateQuiz = async (topic: string): Promise<QuizQuestion[]> => {
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: model,
            contents: `Crea un cuestionario de 5 preguntas de opción múltiple sobre el tema: "${topic}". Cada pregunta debe tener 4 opciones y una respuesta correcta claramente identificada.`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.ARRAY,
                    items: {
                        type: Type.OBJECT,
                        properties: {
                            pregunta: {
                                type: Type.STRING,
                                description: "La pregunta del cuestionario.",
                            },
                            opciones: {
                                type: Type.ARRAY,
                                items: { type: Type.STRING },
                                description: "Un arreglo de 4 posibles respuestas.",
                            },
                            respuestaCorrecta: {
                                type: Type.STRING,
                                description: "La respuesta correcta exacta de entre las opciones.",
                            },
                        },
                        required: ["pregunta", "opciones", "respuestaCorrecta"],
                    },
                },
            },
        });
        
        const jsonText = response.text.trim();
        const quiz = JSON.parse(jsonText);
        return quiz;
    } catch (error) {
        console.error("Error al generar el cuestionario:", error);
        throw new Error("No se pudo generar el cuestionario. Inténtalo de nuevo.");
    }
};

export const generateSummary = async (text: string): Promise<string> => {
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: model,
            contents: `Resume el siguiente texto o tema en una lista de puntos clave concisos. Extrae solo la información más importante. Texto/Tema: "${text}"`,
        });

        return response.text;
    } catch (error) {
        console.error("Error al generar el resumen:", error);
        throw new Error("No se pudo generar el resumen. Inténtalo de nuevo.");
    }
};
